// Copyright 2022 Markus Knutsson (@TweetyDaBird)
// SPDX-License-Identifier: GPL-2.0-or-later

#pragma once

//
// Oli's changes to the configuration
//
#define TAPPING_TERM 150

